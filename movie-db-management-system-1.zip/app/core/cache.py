import time
from typing import Any, Optional

_CACHE: dict[str, tuple[float, Any]] = {}


def get_cache(key: str) -> Optional[Any]:
    entry = _CACHE.get(key)
    if not entry:
        return None
    expires_at, value = entry
    if time.time() > expires_at:
        del _CACHE[key]
        return None
    return value


def set_cache(key: str, value: Any, ttl: int = 60) -> None:
    _CACHE[key] = (time.time() + ttl, value)


async def get_or_set(key: str, factory, ttl: int = 60):
    val = get_cache(key)
    if val is not None:
        return val
    val = await factory()
    set_cache(key, val, ttl=ttl)
    return val
