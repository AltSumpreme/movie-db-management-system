from fastapi import Depends, HTTPException
from app.core.auth import get_current_user


def require_role(role: str):
    def _require(user=Depends(get_current_user)):
        if not user or getattr(user, "role", "User").lower() != role.lower():
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user

    return _require


def require_admin(user=Depends(get_current_user)):
    if not user or getattr(user, "role", "User").lower() != "admin":
        raise HTTPException(status_code=403, detail="Admin privileges required")
    return user
