from pydantic import BaseModel
from typing import List


class WatchlistAdd(BaseModel):
    movie_id: str


class WatchlistRemove(BaseModel):
    movie_id: str


class WatchlistRead(BaseModel):
    user_id: str
    movie_ids: List[str]
