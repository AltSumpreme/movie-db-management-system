from pydantic import BaseModel
from typing import Optional


class ActorCreate(BaseModel):
    name: str
    biography: Optional[str] = None
    birth_date: Optional[str] = None


class ActorUpdate(BaseModel):
    name: Optional[str]
    biography: Optional[str]
    birth_date: Optional[str]


class ActorRead(BaseModel):
    id: str
    name: str
    biography: Optional[str]
    birth_date: Optional[str]
    created_at: str
