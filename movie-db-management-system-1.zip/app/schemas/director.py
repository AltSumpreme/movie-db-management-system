from pydantic import BaseModel
from typing import Optional


class DirectorCreate(BaseModel):
    name: str
    biography: Optional[str] = None
    birth_date: Optional[str] = None


class DirectorUpdate(BaseModel):
    name: Optional[str]
    biography: Optional[str]
    birth_date: Optional[str]


class DirectorRead(BaseModel):
    id: str
    name: str
    biography: Optional[str]
    birth_date: Optional[str]
    created_at: str
