from pydantic import BaseModel, EmailStr, Field
from typing import Optional


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(min_length=6)


class UserRead(BaseModel):
    id: str
    username: str
    email: EmailStr
    is_active: bool
    role: str
    created_at: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str
