from pydantic import BaseModel, Field
from typing import Optional


class ReviewCreate(BaseModel):
    movie_id: str
    rating: int = Field(..., ge=1, le=5)
    review_text: Optional[str] = None


class ReviewUpdate(BaseModel):
    rating: Optional[int] = Field(None, ge=1, le=5)
    review_text: Optional[str] = None


class ReviewRead(BaseModel):
    id: str
    user_id: str
    movie_id: str
    rating: int
    review_text: Optional[str]
    created_at: str
