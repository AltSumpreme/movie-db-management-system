from pydantic import BaseModel, Field
from typing import Optional, List


class MovieCreate(BaseModel):
    title: str
    description: Optional[str] = None
    release_year: Optional[int] = None
    duration_minutes: Optional[int] = None
    language: Optional[str] = None
    genres: List[str] = Field(default_factory=list)
    director_id: Optional[str] = None
    actor_ids: List[str] = Field(default_factory=list)
    poster_url: Optional[str] = None


class MovieUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    release_year: Optional[int] = None
    duration_minutes: Optional[int] = None
    language: Optional[str] = None
    genres: Optional[List[str]] = None
    director_id: Optional[str] = None
    actor_ids: Optional[List[str]] = None
    poster_url: Optional[str] = None


class MovieRead(BaseModel):
    id: str
    title: str
    description: Optional[str]
    release_year: Optional[int]
    duration_minutes: Optional[int]
    language: Optional[str]
    genres: List[str]
    director_id: Optional[str]
    actor_ids: List[str]
    poster_url: Optional[str]
    created_at: str



class PersonRead(BaseModel):
    id: str
    name: str
    biography: Optional[str]
    birth_date: Optional[str]


class MovieDetail(BaseModel):
    id: str
    title: str
    description: Optional[str]
    release_year: Optional[int]
    duration_minutes: Optional[int]
    language: Optional[str]
    genres: List[str]
    poster_url: Optional[str]
    created_at: str
    director: Optional[PersonRead]
    actors: List[PersonRead]
