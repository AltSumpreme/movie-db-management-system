from datetime import datetime

from beanie import Document, Indexed
from pymongo import IndexModel, ASCENDING


class Review(Document):
    user_id: str = Indexed()
    movie_id: str = Indexed()
    rating: int
    review_text: str | None = None
    created_at: datetime = datetime.utcnow()

    class Settings:
        name = "reviews"
        indexes = [
            IndexModel([("user_id", ASCENDING), ("movie_id", ASCENDING)], unique=True, name="user_movie_unique_idx"),
            IndexModel([("movie_id", ASCENDING)], name="movie_idx"),
        ]

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "user_id": self.user_id,
            "movie_id": self.movie_id,
            "rating": self.rating,
            "review_text": self.review_text,
            "created_at": self.created_at.isoformat(),
        }
