from datetime import datetime
from typing import Optional

from beanie import Document, Indexed
from pydantic import EmailStr


class User(Document):
    username: str = Indexed(unique=True)
    email: EmailStr = Indexed(unique=True)
    password_hash: str
    refresh_token_hash: Optional[str] = None
    is_active: bool = True
    role: str = "User"
    created_at: datetime = datetime.utcnow()

    class Settings:
        name = "users"

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "username": str(self.username),
            "email": str(self.email),
            "is_active": self.is_active,
            "role": self.role,
            "created_at": self.created_at.isoformat(),
        }
