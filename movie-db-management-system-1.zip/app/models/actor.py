from datetime import datetime

from beanie import Document


class Actor(Document):
    name: str
    biography: str | None = None
    birth_date: str | None = None
    created_at: datetime = datetime.utcnow()

    class Settings:
        name = "actors"

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "name": self.name,
            "biography": self.biography,
            "birth_date": self.birth_date,
            "created_at": self.created_at.isoformat(),
        }
