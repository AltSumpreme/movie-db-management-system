from datetime import datetime

from beanie import Document
from pymongo import IndexModel, ASCENDING


class Watchlist(Document):
    user_id: str
    movie_ids: list[str] = []
    created_at: datetime = datetime.utcnow()

    class Settings:
        name = "watchlists"
        indexes = [
            IndexModel([("user_id", ASCENDING)], unique=True, name="user_watchlist_unique"),
        ]

    def to_dict(self) -> dict:
        return {"id": str(self.id), "user_id": self.user_id, "movie_ids": self.movie_ids, "created_at": self.created_at.isoformat()}
