from datetime import datetime
from typing import Optional

from beanie import Document, Indexed
from pydantic import Field
from pymongo import ASCENDING, TEXT
from pymongo.operations import IndexModel


class Movie(Document):
    title: str = Indexed()
    description: Optional[str] = None
    release_year: Optional[int] = None
    duration_minutes: Optional[int] = None
    language: Optional[str] = None
    genres: list[str] = Field(default_factory=list)
    director_id: Optional[str] = None
    actor_ids: list[str] = Field(default_factory=list)
    poster_url: Optional[str] = None
    created_at: datetime = datetime.utcnow()

    class Settings:
        name = "movies"
        indexes = [
            IndexModel([("title", TEXT)], name="title_text_idx"),
            IndexModel([("genres", ASCENDING)], name="genres_idx"),
            IndexModel([("release_year", ASCENDING)], name="release_year_idx"),
        ]

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "title": self.title,
            "description": self.description,
            "release_year": self.release_year,
            "duration_minutes": self.duration_minutes,
            "language": self.language,
            "genres": self.genres,
            "director_id": self.director_id,
            "actor_ids": self.actor_ids,
            "poster_url": self.poster_url,
            "created_at": self.created_at.isoformat(),
        }
