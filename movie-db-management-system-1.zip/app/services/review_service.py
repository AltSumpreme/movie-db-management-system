from typing import Optional, List, Tuple
from pymongo import DESCENDING, ASCENDING

from app.models.review import Review
from app.database import connection


async def create_review(user_id: str, data: dict) -> Review:
    # enforce unique per user/movie
    existing = await Review.find_one({"user_id": user_id, "movie_id": data.get("movie_id")})
    if existing:
        raise ValueError("User has already reviewed this movie")
    review = Review(user_id=user_id, **data)
    await review.insert()
    return review


async def update_review(review_id: str, user_id: str, data: dict) -> Optional[Review]:
    review = await Review.get(review_id)
    if not review:
        return None
    if review.user_id != user_id:
        raise PermissionError("Not permitted")
    for k, v in data.items():
        if v is not None:
            setattr(review, k, v)
    await review.save()
    return review


async def delete_review(review_id: str, user_id: str, is_admin: bool = False) -> bool:
    review = await Review.get(review_id)
    if not review:
        return False
    if not is_admin and review.user_id != user_id:
        raise PermissionError("Not permitted")
    await review.delete()
    return True


async def list_reviews_for_movie(movie_id: str) -> List[Review]:
    return await Review.find({"movie_id": movie_id}).to_list()


async def average_rating(movie_id: str) -> Optional[float]:
    db = connection.client.get_default_database()
    coll = db[Review.Settings.name]
    pipeline = [
        {"$match": {"movie_id": movie_id}},
        {"$group": {"_id": "$movie_id", "avg": {"$avg": "$rating"}, "count": {"$sum": 1}}},
    ]
    docs = await coll.aggregate(pipeline).to_list(length=1)
    if not docs:
        return None
    return float(docs[0].get("avg"))


async def total_reviews(movie_id: str) -> int:
    db = connection.client.get_default_database()
    coll = db[Review.Settings.name]
    return await coll.count_documents({"movie_id": movie_id})


async def top_rated_movies(limit: int = 10, min_reviews: int = 1) -> List[dict]:
    db = connection.client.get_default_database()
    coll = db[Review.Settings.name]
    pipeline = [
        {"$group": {"_id": "$movie_id", "avg": {"$avg": "$rating"}, "count": {"$sum": 1}}},
        {"$match": {"count": {"$gte": min_reviews}}},
        {"$sort": {"avg": -1, "count": -1}},
        {"$limit": limit},
        {"$project": {"movie_id": "$_id", "avg": 1, "count": 1, "_id": 0}},
    ]
    docs = await coll.aggregate(pipeline).to_list(length=limit)
    return docs
