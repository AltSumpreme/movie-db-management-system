from typing import Optional, List

from app.models.actor import Actor


async def create_actor(data: dict) -> Actor:
    actor = Actor(**data)
    await actor.insert()
    return actor


async def get_actor(actor_id: str) -> Optional[Actor]:
    return await Actor.get(actor_id)


async def update_actor(actor_id: str, data: dict) -> Optional[Actor]:
    actor = await Actor.get(actor_id)
    if not actor:
        return None
    for k, v in data.items():
        if v is not None:
            setattr(actor, k, v)
    await actor.save()
    return actor


async def delete_actor(actor_id: str) -> bool:
    actor = await Actor.get(actor_id)
    if not actor:
        return False
    await actor.delete()
    return True


async def list_actors() -> List[Actor]:
    return await Actor.find_all().to_list()
