from typing import Optional

from app.models.user import User


async def create_user(username: str, email: str, password_hash: str, role: str = "User") -> User:
    user = User(username=username, email=email, password_hash=password_hash, role=role)
    await user.insert()
    return user


async def get_user_by_id(user_id: str) -> Optional[User]:
    return await User.get(user_id)


async def get_user_by_email(email: str) -> Optional[User]:
    return await User.find_one({"email": email})
