from typing import List
from pymongo import DESCENDING

from app.database import connection


async def top_rated(limit: int = 10, min_reviews: int = 1) -> List[dict]:
    db = connection.client.get_default_database()
    reviews = db["reviews"]
    pipeline = [
        {"$group": {"_id": "$movie_id", "avg": {"$avg": "$rating"}, "count": {"$sum": 1}}},
        {"$match": {"count": {"$gte": min_reviews}}},
        {"$sort": {"avg": -1, "count": -1}},
        {"$limit": limit},
        {"$lookup": {"from": "movies", "let": {"mid": "$_id"}, "pipeline": [{"$match": {"$expr": {"$eq": [{"$toString": "$_id"}, "$$mid"]}}}, {"$project": {"title": 1, "poster_url": 1}}], "as": "movie"}},
        {"$unwind": {"path": "$movie", "preserveNullAndEmptyArrays": True}},
        {"$project": {"movie_id": "$_id", "avg": 1, "count": 1, "title": "$movie.title", "poster_url": "$movie.poster_url", "_id": 0}},
    ]
    docs = await reviews.aggregate(pipeline).to_list(length=limit)
    return docs


async def most_reviewed(limit: int = 10) -> List[dict]:
    db = connection.client.get_default_database()
    reviews = db["reviews"]
    pipeline = [
        {"$group": {"_id": "$movie_id", "count": {"$sum": 1}, "avg": {"$avg": "$rating"}}},
        {"$sort": {"count": -1, "avg": -1}},
        {"$limit": limit},
        {"$lookup": {"from": "movies", "let": {"mid": "$_id"}, "pipeline": [{"$match": {"$expr": {"$eq": [{"$toString": "$_id"}, "$$mid"]}}}, {"$project": {"title": 1, "poster_url": 1}}], "as": "movie"}},
        {"$unwind": {"path": "$movie", "preserveNullAndEmptyArrays": True}},
        {"$project": {"movie_id": "$_id", "count": 1, "avg": 1, "title": "$movie.title", "poster_url": "$movie.poster_url", "_id": 0}},
    ]
    docs = await reviews.aggregate(pipeline).to_list(length=limit)
    return docs


async def popular_genres(limit: int = 10) -> List[dict]:
    db = connection.client.get_default_database()
    movies = db["movies"]
    pipeline = [
        {"$unwind": "$genres"},
        {"$group": {"_id": "$genres", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": limit},
        {"$project": {"genre": "$_id", "count": 1, "_id": 0}},
    ]
    docs = await movies.aggregate(pipeline).to_list(length=limit)
    return docs


async def recently_added(limit: int = 10) -> List[dict]:
    db = connection.client.get_default_database()
    movies = db["movies"]
    pipeline = [
        {"$sort": {"created_at": -1}},
        {"$limit": limit},
        {"$project": {"movie_id": {"$toString": "$_id"}, "title": 1, "poster_url": 1, "created_at": 1, "_id": 0}},
    ]
    docs = await movies.aggregate(pipeline).to_list(length=limit)
    return docs
