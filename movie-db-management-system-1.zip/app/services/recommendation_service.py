from typing import List, Optional
from bson import ObjectId

from app.database import connection


async def get_preferred_genres(user_id: str, watchlist_ids: List[str]) -> List[str]:
    db = connection.client.get_default_database()
    reviews = db["reviews"]
    movies = db["movies"]

    # Genres from highly-rated movies by the user (rating >=4)
    pipeline_user_genres = [
        {"$match": {"user_id": user_id, "rating": {"$gte": 4}}},
        {"$lookup": {"from": "movies", "localField": "movie_id", "foreignField": "_id", "as": "movie_docs"}},
        {"$unwind": {"path": "$movie_docs", "preserveNullAndEmptyArrays": False}},
        {"$unwind": "$movie_docs.genres"},
        {"$group": {"_id": "$movie_docs.genres", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]
    # Note: foreignField match expects same types; above may not match if movie_id stored as string. We'll fallback to joining by string equality.
    user_genres = []
    try:
        docs = await reviews.aggregate(pipeline_user_genres).to_list(length=50)
        user_genres = [d["_id"] for d in docs]
    except Exception:
        user_genres = []

    # Genres from watchlist movies
    wl_genres = []
    if watchlist_ids:
        # try to convert to ObjectId where possible
        oid_list = []
        for mid in watchlist_ids:
            try:
                oid_list.append(ObjectId(mid))
            except Exception:
                pass
        if oid_list:
            pipeline_wl = [
                {"$match": {"_id": {"$in": oid_list}}},
                {"$unwind": "$genres"},
                {"$group": {"_id": "$genres", "count": {"$sum": 1}}},
                {"$sort": {"count": -1}},
            ]
            try:
                docs = await movies.aggregate(pipeline_wl).to_list(length=50)
                wl_genres = [d["_id"] for d in docs]
            except Exception:
                wl_genres = []

    # Merge preferences, giving priority to user_genres then watchlist genres
    merged = []
    seen = set()
    for g in user_genres + wl_genres:
        if g and g not in seen:
            merged.append(g)
            seen.add(g)
    return merged


async def get_recommendations(user_id: str, limit: int = 10) -> List[dict]:
    db = connection.client.get_default_database()
    movies = db["movies"]
    reviews = db["reviews"]
    watchlists = db["watchlists"]

    # Get user's watchlist movie ids
    wl_doc = await watchlists.find_one({"user_id": user_id})
    watchlist_ids: List[str] = wl_doc["movie_ids"] if wl_doc and "movie_ids" in wl_doc else []

    # Get list of movies the user has already reviewed (so we can deprioritize them)
    reviewed_cursor = reviews.find({"user_id": user_id}, {"movie_id": 1})
    reviewed = set()
    async for r in reviewed_cursor:
        reviewed.add(r.get("movie_id"))

    preferred_genres = await get_preferred_genres(user_id, watchlist_ids)

    if not preferred_genres:
        # fallback: recommend top-rated overall
        pipeline = [
            {"$group": {"_id": "$movie_id", "avg": {"$avg": "$rating"}, "count": {"$sum": 1}}},
            {"$sort": {"avg": -1, "count": -1}},
            {"$limit": limit},
            {"$lookup": {"from": "movies", "let": {"mid": "$_id"}, "pipeline": [{"$match": {"$expr": {"$eq": [{"$toString": "$_id"}, "$$mid"]}}}, {"$project": {"title": 1, "genres": 1, "poster_url": 1}}], "as": "movie"}},
            {"$unwind": {"path": "$movie", "preserveNullAndEmptyArrays": True}},
            {"$project": {"movie_id": "$_id", "avg": 1, "count": 1, "title": "$movie.title", "genres": "$movie.genres", "poster_url": "$movie.poster_url", "_id": 0}},
        ]
        docs = await reviews.aggregate(pipeline).to_list(length=limit)
        return docs

    # Build pipeline to score movies by genre overlap and rating
    pipeline = [
        # exclude movies in watchlist
        {"$match": {"$expr": {"$not": {"$in": [{"$toString": "$_id"}, watchlist_ids]}}}},
        # compute number of matching genres
        {"$addFields": {"common_genres_count": {"$size": {"$setIntersection": ["$genres", preferred_genres]}}}},
        # lookup review stats
        {"$lookup": {"from": "reviews", "localField": {"$toString": "$_id"}, "foreignField": "movie_id", "as": "movie_reviews"}},
        {"$addFields": {"avg_rating": {"$cond": [{"$gt": [{"$size": "$movie_reviews"}, 0]}, {"$avg": "$movie_reviews.rating"}, None]}, "review_count": {"$size": "$movie_reviews"}}},
        # score: weight genre match and avg_rating
        {"$addFields": {"score": {"$add": [{"$multiply": ["$common_genres_count", 3]}, {"$ifNull": ["$avg_rating", 0]}]}}},
        # exclude movies with zero score
        {"$match": {"score": {"$gt": 0}}},
        {"$sort": {"score": -1, "review_count": -1}},
        {"$limit": limit},
        {"$project": {"movie_id": {"$toString": "$_id"}, "title": 1, "genres": 1, "poster_url": 1, "avg_rating": 1, "review_count": 1, "score": 1, "_id": 0}},
    ]

    # Because we used $toString in match, some MongoDB versions may not accept it in this context; handle exceptions by fallbacks in caller.
    docs = await movies.aggregate(pipeline).to_list(length=limit)

    # Filter out movies the user already reviewed
    results = [d for d in docs if d.get("movie_id") not in reviewed]
    return results[:limit]
