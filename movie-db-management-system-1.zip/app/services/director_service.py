from typing import Optional, List

from app.models.director import Director


async def create_director(data: dict) -> Director:
    director = Director(**data)
    await director.insert()
    return director


async def get_director(director_id: str) -> Optional[Director]:
    return await Director.get(director_id)


async def update_director(director_id: str, data: dict) -> Optional[Director]:
    director = await Director.get(director_id)
    if not director:
        return None
    for k, v in data.items():
        if v is not None:
            setattr(director, k, v)
    await director.save()
    return director


async def delete_director(director_id: str) -> bool:
    director = await Director.get(director_id)
    if not director:
        return False
    await director.delete()
    return True


async def list_directors() -> List[Director]:
    return await Director.find_all().to_list()
