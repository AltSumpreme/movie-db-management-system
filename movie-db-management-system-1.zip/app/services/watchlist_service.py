from typing import Optional, List
from pymongo import UpdateOne

from app.models.watchlist import Watchlist
from app.database.connection import client
from app.services.movie_service import get_movie_with_relations


async def add_movie_to_watchlist(user_id: str, movie_id: str) -> Watchlist:
    wl = await Watchlist.find_one({"user_id": user_id})
    if not wl:
        wl = Watchlist(user_id=user_id, movie_ids=[movie_id])
        await wl.insert()
        return wl
    # prevent duplicates
    if movie_id in wl.movie_ids:
        return wl
    wl.movie_ids.append(movie_id)
    await wl.save()
    return wl


async def remove_movie_from_watchlist(user_id: str, movie_id: str) -> Optional[Watchlist]:
    wl = await Watchlist.find_one({"user_id": user_id})
    if not wl:
        return None
    if movie_id in wl.movie_ids:
        wl.movie_ids.remove(movie_id)
        await wl.save()
    return wl


async def get_watchlist(user_id: str) -> List[dict]:
    wl = await Watchlist.find_one({"user_id": user_id})
    if not wl:
        return []
    # load full movie details for each movie in watchlist
    results = []
    for mid in wl.movie_ids:
        movie = await get_movie_with_relations(mid)
        if movie:
            results.append(movie)
    return results
