from typing import Optional, Tuple, List
from pymongo import ASCENDING, DESCENDING

from app.database import connection
from app.models.movie import Movie
from bson import ObjectId


async def create_movie(data: dict) -> Movie:
    movie = Movie(**data)
    await movie.insert()
    return movie


async def get_movie(movie_id: str) -> Optional[Movie]:
    return await Movie.get(movie_id)


async def update_movie(movie_id: str, data: dict) -> Optional[Movie]:
    movie = await Movie.get(movie_id)
    if not movie:
        return None
    for k, v in data.items():
        if v is not None:
            setattr(movie, k, v)
    await movie.save()
    return movie


async def delete_movie(movie_id: str) -> bool:
    movie = await Movie.get(movie_id)
    if not movie:
        return False
    await movie.delete()
    return True


async def list_movies(page: int = 1, per_page: int = 10, sort_by: str = "created_at", sort_order: str = "desc", search: Optional[str] = None, genre: Optional[str] = None, release_year: Optional[int] = None) -> Tuple[int, List[Movie]]:
    db = connection.client.get_default_database()
    coll = db[Movie.Settings.name]
    query = {}
    if search:
        # use text search if available; fallback to regex
        query.update({"$or": [{"title": {"$regex": search, "$options": "i"}}, {"description": {"$regex": search, "$options": "i"}}]})
    if genre:
        query.update({"genres": genre})
    if release_year:
        query.update({"release_year": release_year})

    total = await coll.count_documents(query)

    sort_dir = DESCENDING if sort_order == "desc" else ASCENDING
    # protect sort_by to allowed fields
    allowed_sort = {"title", "release_year", "created_at", "duration_minutes"}
    if sort_by not in allowed_sort:
        sort_by = "created_at"

    cursor = coll.find(query).sort(sort_by, sort_dir).skip((page - 1) * per_page).limit(per_page)
    results = []
    async for doc in cursor:
        # convert to Movie instance for consistency
        movie = Movie(**doc)
        results.append(movie)

    return total, results


async def get_movie_with_relations(movie_id: str) -> Optional[dict]:
    db = connection.client.get_default_database()
    coll = db[Movie.Settings.name]
    try:
        mid = ObjectId(movie_id)
    except Exception:
        return None

    pipeline = [
        {"$match": {"_id": mid}},
        {
            "$lookup": {
                "from": "actors",
                "let": {"actor_ids": "$actor_ids"},
                "pipeline": [
                    {"$match": {"$expr": {"$in": [{"$toString": "$_id"}, "$$actor_ids"]}}},
                    {"$project": {"created_at": 1, "name": 1, "biography": 1, "birth_date": 1}}
                ],
                "as": "actors",
            }
        },
        {
            "$lookup": {
                "from": "directors",
                "let": {"director_id": "$director_id"},
                "pipeline": [
                    {"$match": {"$expr": {"$eq": [{"$toString": "$_id"}, "$$director_id"]}}},
                    {"$project": {"created_at": 1, "name": 1, "biography": 1, "birth_date": 1}}
                ],
                "as": "director",
            }
        },
        {"$unwind": {"path": "$director", "preserveNullAndEmptyArrays": True}},
    ]

    doc = await coll.aggregate(pipeline).to_list(length=1)
    if not doc:
        return None
    result = doc[0]
    # convert ObjectId to str for id fields
    result["id"] = str(result.get("_id"))
    # format actors/director
    actors = []
    for a in result.get("actors", []):
        a["id"] = str(a.get("_id"))
        actors.append({"id": a["id"], "name": a.get("name"), "biography": a.get("biography"), "birth_date": a.get("birth_date")})
    director = None
    if result.get("director"):
        d = result.get("director")
        director = {"id": str(d.get("_id")), "name": d.get("name"), "biography": d.get("biography"), "birth_date": d.get("birth_date")}

    movie = {
        "id": result["id"],
        "title": result.get("title"),
        "description": result.get("description"),
        "release_year": result.get("release_year"),
        "duration_minutes": result.get("duration_minutes"),
        "language": result.get("language"),
        "genres": result.get("genres", []),
        "poster_url": result.get("poster_url"),
        "created_at": result.get("created_at").isoformat() if result.get("created_at") else None,
        "director": director,
        "actors": actors,
    }
    return movie
