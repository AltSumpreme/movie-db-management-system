from datetime import timedelta
from typing import Optional

from passlib.context import CryptContext

from app.core.security import create_access_token, create_refresh_token, decode_token
from app.core.config import settings
from app.models.user import User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


async def authenticate_user(email: str, password: str) -> Optional[User]:
    user = await User.find_one({"email": email})
    if not user:
        return None
    if not verify_password(password, user.password_hash):
        return None
    return user


async def create_tokens_for_user(user: User) -> dict:
    access_token = create_access_token(subject=str(user.id), expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    refresh_token = create_refresh_token(subject=str(user.id), expires_delta=timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS))
    # store hashed refresh token for rotation/validation
    refresh_hash = pwd_context.hash(refresh_token)
    user.refresh_token_hash = refresh_hash
    await user.save()
    return {"access_token": access_token, "refresh_token": refresh_token}


async def rotate_refresh_token(old_refresh_token: str) -> dict:
    # validate and rotate refresh token
    payload = decode_token(old_refresh_token)
    if payload.get("type") != "refresh":
        raise ValueError("Invalid token type")
    user_id = payload.get("sub")
    user = await User.get(user_id)
    if not user or not user.refresh_token_hash:
        raise ValueError("Invalid refresh token")
    # verify hash
    if not pwd_context.verify(old_refresh_token, user.refresh_token_hash):
        raise ValueError("Invalid refresh token")

    # create new tokens
    tokens = await create_tokens_for_user(user)
    return tokens
