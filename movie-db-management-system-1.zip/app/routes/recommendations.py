from fastapi import APIRouter, Depends, Query

from app.services.recommendation_service import get_recommendations
from app.core.auth import get_current_user

router = APIRouter()


@router.get("/")
async def recommendations(limit: int = Query(10, ge=1, le=50), current_user=Depends(get_current_user)):
    recs = await get_recommendations(str(current_user.id), limit=limit)
    return recs
