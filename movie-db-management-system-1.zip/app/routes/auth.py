from datetime import timedelta

from fastapi import APIRouter, HTTPException, Depends, status

from app.schemas.user import UserCreate, UserLogin
from app.schemas.token import Token
from app.services.user_service import create_user, get_user_by_email, get_user_by_id
from app.services.auth_service import get_password_hash, authenticate_user, create_tokens_for_user, rotate_refresh_token
from app.core.security import decode_token

router = APIRouter()


@router.post("/register", response_model=dict)
async def register(payload: UserCreate):
    existing = await get_user_by_email(payload.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    # check username uniqueness
    from app.models.user import User
    if await User.find_one({"username": payload.username}):
        raise HTTPException(status_code=400, detail="Username already taken")
    hashed = get_password_hash(payload.password)
    user = await create_user(username=payload.username, email=payload.email, password_hash=hashed, role="User")
    return {"id": str(user.id), "email": user.email, "username": user.username}


@router.post("/login", response_model=Token)
async def login(payload: UserLogin):
    user = await authenticate_user(payload.email, payload.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password")
    tokens = await create_tokens_for_user(user)
    return Token(access_token=tokens["access_token"], refresh_token=tokens["refresh_token"], token_type="bearer")


@router.post("/refresh", response_model=Token)
async def refresh(refresh: dict):
    token = refresh.get("refresh_token")
    if not token:
        raise HTTPException(status_code=400, detail="refresh_token required")
    try:
        # rotate and return new tokens
        tokens = await rotate_refresh_token(token)
        return Token(access_token=tokens["access_token"], refresh_token=tokens["refresh_token"], token_type="bearer")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
