from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from app.core.cache import get_or_set
from app.services.analytics_service import top_rated as analytics_top_rated, most_reviewed as analytics_most_reviewed, popular_genres as analytics_popular_genres
from app.services.movie_service import create_movie
from app.schemas.movie import MovieCreate

from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
# disable Jinja2 template caching to avoid unhashable globals issues in tests
templates.env.cache = {}


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    # use cache for analytics
    try:
        top_rated = await get_or_set("top_rated", lambda: analytics_top_rated(limit=5), ttl=60)
    except Exception:
        top_rated = []
    try:
        most_reviewed = await get_or_set("most_reviewed", lambda: analytics_most_reviewed(limit=5), ttl=60)
    except Exception:
        most_reviewed = []
    try:
        genres = await get_or_set("popular_genres", lambda: analytics_popular_genres(limit=5), ttl=60)
    except Exception:
        genres = []
    return templates.TemplateResponse(request, "dashboard.html", {"top_rated": tuple(top_rated), "most_reviewed": tuple(most_reviewed), "genres": tuple(genres)})


@router.get("/movies/create", response_class=HTMLResponse)
async def create_movie_form(request: Request):
    return templates.TemplateResponse(request, "create_movie.html")


@router.post("/movies/create")
async def handle_create_movie(request: Request):
    form = await request.form()
    # parse form fields
    title = form.get("title")
    description = form.get("description") or None
    release_year = form.get("release_year") or None
    duration_minutes = form.get("duration_minutes") or None
    language = form.get("language") or None
    genres = form.get("genres") or ""
    director_id = form.get("director_id") or None
    actor_ids = form.get("actor_ids") or ""
    poster_url = form.get("poster_url") or None

    # normalize types
    try:
        release_year = int(release_year) if release_year else None
    except Exception:
        release_year = None
    try:
        duration_minutes = int(duration_minutes) if duration_minutes else None
    except Exception:
        duration_minutes = None

    genres_list = [g.strip() for g in genres.split(",") if g.strip()]
    actor_ids_list = [a.strip() for a in actor_ids.split(",") if a.strip()]

    payload = {
        "title": title,
        "description": description,
        "release_year": release_year,
        "duration_minutes": duration_minutes,
        "language": language,
        "genres": genres_list,
        "director_id": director_id,
        "actor_ids": actor_ids_list,
        "poster_url": poster_url,
    }

    movie = await create_movie(payload)
    # redirect to movie detail (API) or dashboard
    mid = movie.to_dict().get("id")
    return RedirectResponse(url=f"/api/movies/{mid}", status_code=303)
