from fastapi import APIRouter, Query, Depends

from app.services.analytics_service import top_rated, most_reviewed, popular_genres, recently_added
from app.core.cache import get_or_set
from app.core.rbac import require_admin

router = APIRouter()


@router.get("/top-rated")
async def get_top_rated(limit: int = Query(10, ge=1, le=100), min_reviews: int = Query(1, ge=1), ttl: int = Query(60), user=Depends(require_admin)):
    key = f"analytics:top_rated:{limit}:{min_reviews}"
    return await get_or_set(key, lambda: top_rated(limit=limit, min_reviews=min_reviews), ttl=ttl)


@router.get("/most-reviewed")
async def get_most_reviewed(limit: int = Query(10, ge=1, le=100), ttl: int = Query(60), user=Depends(require_admin)):
    key = f"analytics:most_reviewed:{limit}"
    return await get_or_set(key, lambda: most_reviewed(limit=limit), ttl=ttl)


@router.get("/popular-genres")
async def get_popular_genres(limit: int = Query(10, ge=1, le=100), ttl: int = Query(300), user=Depends(require_admin)):
    key = f"analytics:popular_genres:{limit}"
    return await get_or_set(key, lambda: popular_genres(limit=limit), ttl=ttl)


@router.get("/recently-added")
async def get_recently_added(limit: int = Query(10, ge=1, le=100), ttl: int = Query(60), user=Depends(require_admin)):
    key = f"analytics:recently_added:{limit}"
    return await get_or_set(key, lambda: recently_added(limit=limit), ttl=ttl)
