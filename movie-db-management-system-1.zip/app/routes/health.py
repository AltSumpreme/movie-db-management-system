from fastapi import APIRouter
from app.database import connection

router = APIRouter()


@router.get("/", summary="Health check")
async def health_check():
    ok = False
    try:
        # ping the MongoDB server
        await connection.client.admin.command("ping")
        ok = True
    except Exception:
        ok = False
    return {"status": "ok" if ok else "error"}
