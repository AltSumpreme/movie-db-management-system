from fastapi import APIRouter, Depends

from app.schemas.user import UserRead
from app.core.auth import get_current_user

router = APIRouter()


@router.get("/me", response_model=UserRead)
async def read_users_me(current_user=Depends(get_current_user)):
    return UserRead(**current_user.to_dict())
