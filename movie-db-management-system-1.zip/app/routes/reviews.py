from fastapi import APIRouter, Depends, HTTPException

from app.schemas.review import ReviewCreate, ReviewRead, ReviewUpdate
from app.services.review_service import create_review, update_review, delete_review, average_rating, total_reviews, top_rated_movies
from app.core.auth import get_current_user

router = APIRouter()


@router.post("/", response_model=ReviewRead)
async def create(payload: ReviewCreate, current_user=Depends(get_current_user)):
    try:
        review = await create_review(str(current_user.id), payload.model_dump())
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return ReviewRead(**review.to_dict())


@router.put("/{review_id}", response_model=ReviewRead)
async def update(review_id: str, payload: ReviewUpdate, current_user=Depends(get_current_user)):
    try:
        review = await update_review(review_id, str(current_user.id), payload.model_dump(exclude_none=True))
    except PermissionError:
        raise HTTPException(status_code=403, detail="Forbidden")
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    return ReviewRead(**review.to_dict())


@router.delete("/{review_id}")
async def remove(review_id: str, current_user=Depends(get_current_user)):
    try:
        is_admin = getattr(current_user, "role", "User").lower() == "admin"
        ok = await delete_review(review_id, str(current_user.id), is_admin=is_admin)
    except PermissionError:
        raise HTTPException(status_code=403, detail="Forbidden")
    if not ok:
        raise HTTPException(status_code=404, detail="Review not found")
    return {"status": "deleted"}


@router.get("/movie/{movie_id}/metrics")
async def movie_metrics(movie_id: str):
    avg = await average_rating(movie_id)
    total = await total_reviews(movie_id)
    return {"movie_id": movie_id, "average_rating": avg, "total_reviews": total}


@router.get("/top")
async def get_top(limit: int = 10, min_reviews: int = 1):
    docs = await top_rated_movies(limit=limit, min_reviews=min_reviews)
    return docs
