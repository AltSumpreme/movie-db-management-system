from fastapi import APIRouter, Depends, HTTPException

from app.schemas.actor import ActorCreate, ActorRead, ActorUpdate
from app.services.actor_service import create_actor, get_actor, update_actor, delete_actor, list_actors
from app.core.auth import get_current_user
from app.core.rbac import require_admin

router = APIRouter()


@router.post("/", response_model=ActorRead)
async def create(payload: ActorCreate, user=Depends(require_admin)):
    actor = await create_actor(payload.model_dump())
    return ActorRead(**actor.to_dict())


@router.get("/", response_model=list[ActorRead])
async def list_all():
    actors = await list_actors()
    return [ActorRead(**a.to_dict()) for a in actors]


@router.get("/{actor_id}", response_model=ActorRead)
async def get_one(actor_id: str):
    actor = await get_actor(actor_id)
    if not actor:
        raise HTTPException(status_code=404, detail="Actor not found")
    return ActorRead(**actor.to_dict())


@router.put("/{actor_id}", response_model=ActorRead)
async def update(actor_id: str, payload: ActorUpdate, user=Depends(require_admin)):
    actor = await update_actor(actor_id, payload.model_dump(exclude_none=True))
    if not actor:
        raise HTTPException(status_code=404, detail="Actor not found")
    return ActorRead(**actor.to_dict())


@router.delete("/{actor_id}")
async def remove(actor_id: str, user=Depends(require_admin)):
    ok = await delete_actor(actor_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Actor not found")
    return {"status": "deleted"}
