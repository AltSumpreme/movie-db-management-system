from fastapi import APIRouter, Depends, HTTPException

from app.schemas.director import DirectorCreate, DirectorRead, DirectorUpdate
from app.services.director_service import create_director, get_director, update_director, delete_director, list_directors
from app.core.auth import get_current_user
from app.core.rbac import require_admin

router = APIRouter()


@router.post("/", response_model=DirectorRead)
async def create(payload: DirectorCreate, user=Depends(require_admin)):
    director = await create_director(payload.model_dump())
    return DirectorRead(**director.to_dict())


@router.get("/", response_model=list[DirectorRead])
async def list_all():
    directors = await list_directors()
    return [DirectorRead(**d.to_dict()) for d in directors]


@router.get("/{director_id}", response_model=DirectorRead)
async def get_one(director_id: str):
    director = await get_director(director_id)
    if not director:
        raise HTTPException(status_code=404, detail="Director not found")
    return DirectorRead(**director.to_dict())


@router.put("/{director_id}", response_model=DirectorRead)
async def update(director_id: str, payload: DirectorUpdate, user=Depends(require_admin)):
    director = await update_director(director_id, payload.model_dump(exclude_none=True))
    if not director:
        raise HTTPException(status_code=404, detail="Director not found")
    return DirectorRead(**director.to_dict())


@router.delete("/{director_id}")
async def remove(director_id: str, user=Depends(require_admin)):
    ok = await delete_director(director_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Director not found")
    return {"status": "deleted"}
