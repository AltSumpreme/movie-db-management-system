from fastapi import APIRouter, Depends, HTTPException

from app.schemas.watchlist import WatchlistAdd, WatchlistRemove
from app.services.watchlist_service import add_movie_to_watchlist, remove_movie_from_watchlist, get_watchlist
from app.core.auth import get_current_user

router = APIRouter()


@router.post("/add")
async def add(payload: WatchlistAdd, current_user=Depends(get_current_user)):
    wl = await add_movie_to_watchlist(str(current_user.id), payload.movie_id)
    return {"status": "added", "movie_ids": wl.movie_ids}


@router.delete("/remove")
async def remove(payload: WatchlistRemove, current_user=Depends(get_current_user)):
    wl = await remove_movie_from_watchlist(str(current_user.id), payload.movie_id)
    if wl is None:
        raise HTTPException(status_code=404, detail="Watchlist not found")
    return {"status": "removed", "movie_ids": wl.movie_ids}


@router.get("/")
async def get_all(current_user=Depends(get_current_user)):
    movies = await get_watchlist(str(current_user.id))
    return movies
