from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from app.schemas.movie import MovieCreate, MovieRead, MovieUpdate
from app.services.movie_service import create_movie, get_movie, update_movie, delete_movie, list_movies, get_movie_with_relations
from app.schemas.movie import MovieDetail
from app.core.rbac import require_admin

router = APIRouter()


@router.post("/", response_model=MovieRead)
async def create(payload: MovieCreate, user=Depends(require_admin)):
    movie = await create_movie(payload.model_dump())
    return MovieRead(**movie.to_dict())


@router.get("/", response_model=list[MovieRead])
async def list_all(page: int = Query(1, ge=1), per_page: int = Query(10, ge=1, le=100), sort_by: str = Query("created_at"), sort_order: str = Query("desc"), search: Optional[str] = None, genre: Optional[str] = None, release_year: Optional[int] = None):
    total, movies = await list_movies(page=page, per_page=per_page, sort_by=sort_by, sort_order=sort_order, search=search, genre=genre, release_year=release_year)
    return [MovieRead(**m.to_dict()) for m in movies]


@router.get("/{movie_id}", response_model=MovieDetail)
async def get_one(movie_id: str):
    movie = await get_movie_with_relations(movie_id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    return MovieDetail(**movie)


@router.put("/{movie_id}", response_model=MovieRead)
async def update(movie_id: str, payload: MovieUpdate, user=Depends(require_admin)):
    movie = await update_movie(movie_id, payload.model_dump(exclude_none=True))
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    return MovieRead(**movie.to_dict())


@router.delete("/{movie_id}")
async def remove(movie_id: str, user=Depends(require_admin)):
    ok = await delete_movie(movie_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Movie not found")
    return {"status": "deleted"}
