from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie

from app.core.config import settings
from app.models.user import User
from app.models.movie import Movie
from app.models.actor import Actor
from app.models.director import Director
from app.models.review import Review
from app.models.watchlist import Watchlist

client: AsyncIOMotorClient | None = None


async def init_db() -> None:
    global client
    # beanie may call `append_metadata` on the underlying client; motor's
    # AsyncIOMotorClient returns a database by default for missing attributes.
    # Add a no-op shim at the class level to remain compatible with beanie.
    if getattr(AsyncIOMotorClient, "append_metadata", None) is None:
        AsyncIOMotorClient.append_metadata = lambda *args, **kwargs: None

    client = AsyncIOMotorClient(settings.MONGO_URI)
    # register all document models and ensure indexes
    await init_beanie(database=client.get_default_database(), document_models=[User, Movie, Actor, Director, Review, Watchlist])


async def close_db() -> None:
    global client
    if client:
        client.close()
