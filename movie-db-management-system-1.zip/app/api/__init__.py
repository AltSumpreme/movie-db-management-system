from fastapi import APIRouter

from app.routes import auth, users, health, movies, actors, directors, reviews, watchlist, analytics, recommendations, dashboard

router = APIRouter()

router.include_router(health.router, prefix="/health", tags=["health"])
router.include_router(auth.router, prefix="/auth", tags=["auth"])
router.include_router(users.router, prefix="/users", tags=["users"])
router.include_router(movies.router, prefix="/movies", tags=["movies"])
router.include_router(actors.router, prefix="/actors", tags=["actors"])
router.include_router(directors.router, prefix="/directors", tags=["directors"])
router.include_router(reviews.router, prefix="/reviews", tags=["reviews"])
router.include_router(watchlist.router, prefix="/watchlist", tags=["watchlist"])
router.include_router(analytics.router, prefix="/analytics", tags=["analytics"])
router.include_router(recommendations.router, prefix="/recommendations", tags=["recommendations"])
router.include_router(dashboard.router, prefix="", tags=["dashboard"])
