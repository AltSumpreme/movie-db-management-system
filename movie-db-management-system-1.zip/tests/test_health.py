import pytest
from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_read_root():
    res = client.get("/")
    assert res.status_code == 200
    assert res.json()["message"] == "Movie DB Management System"


def test_health():
    res = client.get("/api/health/")
    # Health may return ok or error depending on DB; ensure endpoint reachable
    assert res.status_code == 200
