import asyncio
import random
from datetime import datetime

from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie

from app.core.config import settings
from app.models.user import User
from app.models.movie import Movie
from app.models.actor import Actor
from app.models.director import Director
from app.models.review import Review
from app.models.watchlist import Watchlist
from app.services.auth_service import get_password_hash


async def seed():
    client = AsyncIOMotorClient(settings.MONGO_URI)
    await init_beanie(database=client.get_default_database(), document_models=[User, Movie, Actor, Director, Review, Watchlist])

    # clear collections
    await User.get_motor_collection().delete_many({})
    await Movie.get_motor_collection().delete_many({})
    await Actor.get_motor_collection().delete_many({})
    await Director.get_motor_collection().delete_many({})
    await Review.get_motor_collection().delete_many({})
    await Watchlist.get_motor_collection().delete_many({})

    # create users
    users = []
    for i in range(5):
        u = User(username=f'user{i+1}', email=f'user{i+1}@example.com', password_hash=get_password_hash('password'), role='Admin' if i==0 else 'User')
        await u.insert()
        users.append(u)

    # directors
    directors = []
    for i in range(5):
        d = Director(name=f'Director {i+1}', biography='Bio', birth_date='1970-01-01')
        await d.insert()
        directors.append(d)

    # actors
    actors = []
    for i in range(10):
        a = Actor(name=f'Actor {i+1}', biography='Bio', birth_date='1980-01-01')
        await a.insert()
        actors.append(a)

    genres_list = ['Drama', 'Comedy', 'Action', 'Thriller', 'Sci-Fi', 'Romance']

    # movies
    movies = []
    for i in range(20):
        m = Movie(
            title=f'Movie {i+1}',
            description='Description',
            release_year=2000 + (i % 20),
            duration_minutes=90 + i,
            language='English',
            genres=random.sample(genres_list, k=2),
            director_id=str(random.choice(directors).id),
            actor_ids=[str(random.choice(actors).id) for _ in range(3)],
            poster_url='https://via.placeholder.com/150'
        )
        await m.insert()
        movies.append(m)

    # reviews
    for i in range(50):
        user = random.choice(users)
        movie = random.choice(movies)
        rating = random.randint(1, 5)
        rv = Review(user_id=str(user.id), movie_id=str(movie.id), rating=rating, review_text='Nice movie')
        try:
            await rv.insert()
        except Exception:
            pass

    # watchlists
    for u in users:
        wl = Watchlist(user_id=str(u.id), movie_ids=[str(m.id) for m in random.sample(movies, k=5)])
        await wl.insert()

    print('Seeding complete')
    await client.close()


if __name__ == '__main__':
    asyncio.run(seed())
